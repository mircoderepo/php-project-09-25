<?php include __DIR__ . '/header.php'; ?>


<h2>Contato</h2>


<?php include __DIR__ . '/footer.php'; ?>