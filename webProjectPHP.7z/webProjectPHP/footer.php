<hr>
<footer>
  <p>© <?= date('Y'), "<br>", $_SERVER['HTTP_USER_AGENT']; ?> </p>
</footer>
</body>

</html>