<?php include __DIR__ . '/header.php'; ?>


<h2>Galeria</h2>


<?php include __DIR__ . '/footer.php'; ?>