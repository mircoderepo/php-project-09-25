<?php require_once __DIR__ . '/helpers.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <title></title>
</head>

<body>
  <header>
    <h1></h1>
    <nav>
      <a href="index.php">Home</a> |
      <a href="sobre.php">Sobre</a> |
      <a href="galeria.php">Galeria</a> |
      <a href="contato.php">Contato</a>
    </nav>
    <hr>
  </header>